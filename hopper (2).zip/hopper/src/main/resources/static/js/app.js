function hello(){
	
alert("Hello World");
}

function datePage(){
	alert("This is the date template");
}

function timePage(){
	
alert("This is the time template");
}