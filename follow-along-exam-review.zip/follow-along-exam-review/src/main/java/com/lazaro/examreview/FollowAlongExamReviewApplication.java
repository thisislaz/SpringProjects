package com.lazaro.examreview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FollowAlongExamReviewApplication {

	public static void main(String[] args) {
		SpringApplication.run(FollowAlongExamReviewApplication.class, args);
	}

}
