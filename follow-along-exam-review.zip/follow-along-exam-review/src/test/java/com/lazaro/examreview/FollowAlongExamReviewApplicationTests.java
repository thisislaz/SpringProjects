package com.lazaro.examreview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FollowAlongExamReviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
