package com.lazaro.daikichi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DaikichiRouteApplicationTests {

	@Test
	void contextLoads() {
	}

}
