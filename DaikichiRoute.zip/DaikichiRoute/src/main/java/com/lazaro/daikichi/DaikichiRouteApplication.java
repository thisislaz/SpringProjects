package com.lazaro.daikichi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DaikichiRouteApplication {

	public static void main(String[] args) {
		SpringApplication.run(DaikichiRouteApplication.class, args);
	}

}
