package com.lazaro.omijuki;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OmikujiCoreAssignApplication {

	public static void main(String[] args) {
		SpringApplication.run(OmikujiCoreAssignApplication.class, args);
	}

}
