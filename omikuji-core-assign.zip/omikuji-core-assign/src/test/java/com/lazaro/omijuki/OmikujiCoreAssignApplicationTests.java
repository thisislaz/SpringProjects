package com.lazaro.omijuki;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmikujiCoreAssignApplicationTests {

	@Test
	void contextLoads() {
	}

}
