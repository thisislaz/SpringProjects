package com.lazaro.dojoninjaassign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DojoAndNinjaAssignApplication {

	public static void main(String[] args) {
		SpringApplication.run(DojoAndNinjaAssignApplication.class, args);
	}

}
