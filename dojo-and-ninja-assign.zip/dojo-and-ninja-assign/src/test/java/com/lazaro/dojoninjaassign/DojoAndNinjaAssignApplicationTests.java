package com.lazaro.dojoninjaassign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojoAndNinjaAssignApplicationTests {

	@Test
	void contextLoads() {
	}

}
