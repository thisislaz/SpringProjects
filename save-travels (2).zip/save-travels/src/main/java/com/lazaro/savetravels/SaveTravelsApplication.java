package com.lazaro.savetravels;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaveTravelsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaveTravelsApplication.class, args);
	}

}
