package com.lazaro.sessioncounter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SessionCounterApplicationTests {

	@Test
	void contextLoads() {
	}

}
