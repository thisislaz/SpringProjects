package com.lazaro.sessioncounter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SessionCounterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SessionCounterApplication.class, args);
	}

}
